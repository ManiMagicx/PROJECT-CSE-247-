This project used a UCI data set to predict student grades in two subjects - Math and Partueguese based on quantitative and
categorical variables about the students study habits, non-academic support and other such variables. This project was for the 
class ISyE 6414 Regression Analysis taken in Spring 2015.
